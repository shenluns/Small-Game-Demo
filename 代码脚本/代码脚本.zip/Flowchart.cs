using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Fungus
{
    public class Flowchart : MonoBehaviour
    {
       public void ExecuteBlock(string str)
        {
            Debug.Log(str);
        }
    }
}
