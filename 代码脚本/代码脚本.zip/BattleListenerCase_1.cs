public class BattleListenerCase_1 : BattleListenerCase
{
	public int publicSign;
}
