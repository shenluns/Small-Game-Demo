public class BattleListenerCase
{
	public BattleListener bl;

	public virtual bool Condition()
	{
		return false;
	}

	public virtual void OnTrue()
	{
	}
}
