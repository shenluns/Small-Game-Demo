public class AttackDate
{
	public int turn;

	public float DamageToPlayer;

	public float DamageToEnemy;

	public int X;

	public int Y;
}
